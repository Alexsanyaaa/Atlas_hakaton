const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../dist/core.js');

test('rejecting a candidate does not confirm absence or complete the field',()=>{
 const card=C.clone(C.SEEDS[3]),a=card.attrs.find(a=>a.key==='color');
 C.decide(a,'reject');assert.equal(a.state,'rejected');assert.equal(a.value,'');
 assert.equal(C.status(card),'review');assert.equal(C.exportCards([card]).products[0].attributes.some(a=>a.attribute_id==='color'),false);
 C.decide(a,'absent');assert.equal(a.state,'absent');assert.equal(C.status(card),'ready');
 const out=C.exportCards([card]).products[0].attributes.find(a=>a.attribute_id==='color');
 assert.equal(out.value,null);assert.equal(out.decision,'confirmed_absence');assert.deepEqual(out.evidence,[]);
});
test('manual correction removes inherited score and decreases automatic share',()=>{
 const card=C.clone(C.SEEDS[5]),before=C.summary([card]);const a=card.attrs[0];C.decide(a,'edit','Apple');
 const after=C.summary([card]);assert.equal(after.auto,before.auto-1);assert.equal(after.manual,before.manual+1);
 const value=C.exportCards([card]).products[0].attributes[0];assert.equal(value.model_score,null);assert.equal(value.decision,'manual');
 assert.equal(after.auto+after.manual+after.pending,after.total);
});
test('conflicts require an explicit selection instead of a simple accept',()=>{
 const a=C.clone(C.SEEDS[4].attrs.find(a=>a.key==='ram'));
 assert.throws(()=>C.decide(a,'accept'),/Выберите/);C.decide(a,'edit','4 ГБ');assert.equal(a.state,'accepted');
});
test('multivalue correction keeps a literal supporting quotation',()=>{
 const card=C.clone(C.SEEDS[1]),a=card.attrs.find(a=>a.key==='color');C.decide(a,'edit',a.suggested);
 const out=C.exportCards([card]).products[0].attributes.find(a=>a.attribute_id==='color');
 assert.equal(out.value,'серебристый, белый');assert.equal(out.evidence[0].quote,'серебристый и белый');
});
test('all seed quotations are grounded in title or description',()=>{
 for(const card of C.SEEDS)for(const a of card.attrs)for(const e of C.evidence(a,card))assert.ok(card[e.source].includes(e.quote));
});
test('text alone produces category and full Russian units without invented values',()=>{
 const card=C.extract({text:'Смартфон Samsung Galaxy S23+\nЦвет чёрный. Оперативная память — 8 ГБ. Встроенная память — 256 ГБ. Экран 6,6 дюйма.'});
 assert.equal(card.category,'Смартфоны');for(const [key,value]of [['ram','8 ГБ'],['storage','256 ГБ'],['screen','6,6 дюйма'],['color','чёрный']])assert.equal(card.attrs.find(a=>a.key===key).value,value);
 assert.equal(card.attrs.find(a=>a.key==='battery').value,'');
 for(const a of card.attrs)if(a.value)assert.ok(C.evidence(a,card).length);
});
test('accessory brand is not the compatible device brand',()=>{
 const card=C.extract({text:'Чехол Baseus для смартфона Samsung Galaxy S23'});
 assert.equal(card.category,'Аксессуары');assert.equal(card.attrs.find(a=>a.key==='brand').value,'Baseus');
 assert.equal(card.attrs.find(a=>a.key==='model').value,'');
});
test('furniture adjective is not invented as a model',()=>{
 const card=C.extract({text:'Стул COMFUR кухонный\nЦвет бежевый. Материал каркаса — металл.'});
 assert.equal(card.category,'Мебель');assert.equal(card.attrs.find(a=>a.key==='model').value,'');assert.equal(card.attrs.find(a=>a.key==='color').quote,'бежевый');
});
test('CSV accepts BOM, semicolon, quoted multiline text and escaped quotes',()=>{
 const r=C.parseCSV('\uFEFFНазвание;Описание\r\n"Стул";"Цвет белый.\nСерия ""Дом""."');
 assert.equal(r.rows.length,1);assert.equal(r.rows[0]['Описание'],'Цвет белый.\nСерия "Дом".');
 assert.equal(C.mapRows(r.rows,C.defaultMapping(r.headers))[0].title,'Стул');
});
test('bad CSV and JSON are rejected with actionable errors',()=>{
 assert.throws(()=>C.parseCSV('title,description\n"open,quoted'),/кавычки/);
 assert.throws(()=>C.parseCSV('title,title\na,b'),/повторяются/);
 assert.throws(()=>C.parseImport('{}','a.json'),/массив/);
 assert.throws(()=>C.parseImport(JSON.stringify(Array.from({length:101},()=>({title:'A'}))),'a.json'),/100/);
 assert.throws(()=>C.mapRows([{name:'A'}],{title:'',description:''}),/колонку/);
});
test('JSON import can map nonstandard headers and description-only rows',()=>{
 const data=C.parseImport('{"cards":[{"Текст":"Светильник белый"}]}','a.json');
 const rows=C.mapRows(data.rows,{description:'Текст'});assert.equal(rows[0].title,'Светильник белый');assert.equal(rows[0].category,'Освещение');
});
test('normalization works for Cyrillic units and custom dictionary entries',()=>{
 assert.equal(C.normalizeValue('ram','8Гб'),'8 ГБ');assert.equal(C.normalizeValue('storage','256GB'),'256 ГБ');
 const dictionary=[...C.DICTIONARY,{source:'COMFUR',value:'Comfur',type:'Бренд'}];
 const card=C.extract({text:'Стул COMFUR бежевый'},dictionary);assert.equal(card.attrs[0].value,'Comfur');assert.equal(C.SEEDS[8].attrs[0].value,'COMFUR');
});
