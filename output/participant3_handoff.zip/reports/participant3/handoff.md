# Передача участника № 3

Готово: фактический аудит данных, ограниченный безопасный адаптер, условная BIO-подготовка без подачи catalog targets модели, настоящее CPU-дообучение ruBERT-tiny2, сохранённый проверенный checkpoint, частичное CPU-дообучение ruBERT-base и полный GPU-конфиг, standalone extractor, общий resolver и политика confidence. Читайте README_PARTICIPANT_3.md и reports/transformer_experiment.md.

№ 1: data/participant3/manifest.json — только временный prefix split. Нужен общий официальный/согласованный список обязательных атрибутов, репрезентативная выгрузка и evaluator canonical values. Query clicks — не extraction gold. Не включать большие приватные файлы в Git/архив исходников.

№ 2: data/participant3/spans.jsonl — слабые совпадения, не ручной gold. Источник/поле/позиции сохранены, unknown не превращён в отсутствие. Для общего CRF-сравнения согласовать attribute-conditioned постановку либо дать полную BIO-разметку. Normalize/semantic grounding остаются в вашей области. Перед resolver кандидат должен иметь value, unit, normalization_id и проверенную evidence. Review queue: outputs/participant3/review_queue.jsonl.

№ 4: подключить TransformerExtractor.extract(card, schema, requested_attributes); выход — словари контракта v2. При необходимости конвертируйте в ваши общие Pydantic-типы. Артефакт CPU models/participant3_cpu/checkpoint; для основной GPU-модели — configs/transformer.yaml. Модель не использует rules/LLM fallback. Не маркировать review как автоматически заполненное значение. Checkpoint и tokenizer нужно переносить целиком вместе с task_metadata.json. Сохранённый CPU checkpoint не является обученным ruBERT-base.

Git-репозитория в текущей папке нет, поэтому ветка/коммит не создавались. Создан общий Python-каркас; при интеграции сохраните зависимости других участников. source-only архив содержит код/конфиги/отчёты, но не исходные данные и веса.

Дополнительно: модели ai-forever/ruBert-base действительно дообучены на CPU с разморозкой последних двух encoder-слоёв; основной из этих пилотных checkpoint — models/participant3_rubert_pilot/checkpoint. Его silver span-F1=0.3333, precision=0.28, support=51. Это не заменяет полный GPU-прогон и не сравнимо напрямую с tiny2 из-за разных подвыборок. Все исходные .bin веса загружались weights_only=True, результаты сохранены в safetensors. Очередь ручной проверки исключает группы всех выполненных запусков.
