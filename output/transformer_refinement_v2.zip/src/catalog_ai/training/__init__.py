"""Reproducible training entry points."""
