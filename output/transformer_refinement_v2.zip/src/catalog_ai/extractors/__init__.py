"""Independent extraction backends."""
